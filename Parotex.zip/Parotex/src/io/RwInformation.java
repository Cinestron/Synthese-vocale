/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class RwInformation {

   
    public StringBuilder lire(String fichier) {//lecture concetualisée
        BufferedReader in = null;

        //overture du fichier de lecture
        try {
            in = new BufferedReader(new FileReader(fichier));
        } catch (FileNotFoundException ex) {
            System.err.println("Le fichier n'existe pas");
        }
        //Lecture du fichier base des règles.ia
        int lecteurligne;
        StringBuilder ligne = new StringBuilder();
        try {
            while ((lecteurligne = in.read()) != -1) { //parcours du fichier ligne par ligne
                ligne.append(" ").append(in.readLine()).append("\n");

            }
        } catch (IOException ex) {
            System.err.println("Pas des regles dans cette base de regle");
        }
        try {
            in.close();
        } catch (IOException ex) {
            Logger.getLogger(RwInformation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ligne;
    }

   
  

}
