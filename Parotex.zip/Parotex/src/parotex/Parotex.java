/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parotex;

/**
 *
 * @author root
 */
import io.RwInformation;
import t2s.son.*;

public class Parotex {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        File f=new File("test.txt");
//        LecteurTexte lecteur = new LecteurTexte(f, "fin");
       LecteurTexte lecteur = new LecteurTexte();
        RwInformation rw = new RwInformation();
        StringBuilder texte = rw.lire("test.txt");
        System.out.println("" + texte);
        lecteur.setTexte("bonjour à tous");
        lecteur.playAll();

    }

}
